############
Reset Reason
############

About
-----

.. note:: This is a work in progress project and this section is still missing. If you want to contribute, please see the `Contributions Guide <../contributing.html>`_.

Example
-------

To get started with Reset Reason, you can try:

Reset Reason
************

.. literalinclude:: ../../../libraries/ESP32/examples/ResetReason/ResetReason/ResetReason.ino
    :language: arduino
